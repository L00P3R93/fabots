<?php
    header('Location: home');